package com.example.react_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReactApiApplication.class, args);
    }

}
